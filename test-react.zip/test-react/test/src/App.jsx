import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './index.css'

let cardlist = ["1", "2"]

function addCard(new_card) {
  cardlist.push(new_card)
}

function editCard() {

}

function deleteCard() {

}

function App() {
  const [count, setCount] = useState(0)

  return (
    <div className='w-[100%] h-[100%] text-2xl font-bold text-center justify-items-center'>
      <div className='bg-slate-500 w-2/4 min-w-[500px] h-3/4 min-h-[800px]'>
        <div className='relative w-[100%] h-3/4 min-h-[100px] '>
          To-do List
        </div>
        <div className='justify-self-end space-x-5'>
          <button className='bg-green-500 w-[14%] min-w-[100px]'>
            Add
          </button>
          <button className='bg-red-500 w-[14%] min-w-[100px]'>
            Delete
          </button>
        </div>
        <div className='space-y-10 justify-center'>
          {cardlist.map((card, index) => (
            <div key={index} className='bg-pink-300 w-3/4 h-3/4 min-h-[50px] rounded-xl justify-self-center'>
              card: {card}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default App
